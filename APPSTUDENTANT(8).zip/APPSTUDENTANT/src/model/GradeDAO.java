
package model;




import database.DatabaseUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;




/**
 *
 * @author Quang
 * @author Quoc Thai
 */
public class GradeDAO {
    List<Grade> ls= new ArrayList<>();
    
    
 public int add(Grade g){
        Connection conn = null;
        PreparedStatement sttm = null;
        try{
            String sSQL = "insert into Grade(studentID,English,Informatics,physicalEducation) values(?,?,?,?)";
            conn = (Connection)DatabaseUtils.getDBConnect();
            sttm = conn.prepareStatement(sSQL);
            sttm.setString(1, g.getSv().getStudentID());
            sttm.setDouble(2, g.getEnglish());
            sttm.setDouble(3, g.getInformatics());
            sttm.setDouble(4, g.getPhysicalEducation());


            if(sttm.executeUpdate() > 0){
                System.out.println("add completed");
                return 1;
            }
        } catch(Exception e){
            System.out.println("Error: "+e.toString());
        } finally{
            try{
                conn.close();
                sttm.close();
            } catch(Exception e){    
            }
        }
        return -1;
    }
     public int updateGrade(Grade g){
        Connection conn = null;
        PreparedStatement sttm = null;
        try{
            String sSQL = "update Grade set English = ?, Informatics = ?, physicalEducation = ? where studentID = ?";
            conn = (Connection)DatabaseUtils.getDBConnect();
            sttm = conn.prepareStatement(sSQL);
            sttm.setString(4, g.getSv().getStudentID());
            sttm.setDouble(1, g.getEnglish());
            sttm.setDouble(2, g.getInformatics());
            sttm.setDouble(3, g.getPhysicalEducation());


            if(sttm.executeUpdate() > 0){
                System.out.println("add completed");
                return 1;
            }
        } catch(Exception e){
            System.out.println("Error: "+e.toString());
        } finally{
            try{
                conn.close();
                sttm.close();
            } catch(Exception e){    
            }
        }
        return -1;
    }
     
     public int delGrade(String StudentID){
        Connection conn = null;
        PreparedStatement sttm = null;
        try{
            String sSQL = "delete Grade where studentID = 'CS'";
            conn = (Connection)DatabaseUtils.getDBConnect();
            sttm = conn.prepareStatement(sSQL);
            sttm.setString(1, StudentID);
            

            if(sttm.executeUpdate() > 0){
                System.out.println("add completed");
                return 1;
            }
        } catch(Exception e){
            System.out.println("Error: "+e.toString());
        } finally{
            try{
                conn.close();
                sttm.close();
            } catch(Exception e){    
            }
        }
        return -1;
    }
          
     public List<Grade> getAllGrade(){
        List<Grade> ls = new ArrayList<>();
        Connection conn = null;
        Statement sttm = null;
        ResultSet rs = null;
        try{
            String sSQL = "SELECT dbo.Grade.studentID, dbo.Student.studentName, "
                    + "dbo.Grade.Englsh, dbo.Grade.physicalEducation, dbo.Grade.Informatics "
                    + "FROM dbo.Grade INNER JOIN dbo.Student ON dbo.Grade.studentID = dbo.Student.studentID";
            conn = DatabaseUtils.getDBConnect();
            sttm = conn.createStatement();
            rs = sttm.executeQuery(sSQL);
            while(rs.next()){
                Grade g = new Grade();
                g.setSv (new Student(rs.getString(1), rs.getString(2)));
                g.setEnglish(rs.getDouble(3));
                g.setInformatics(rs.getDouble(4));
                g.setPhysicalEducation(rs.getDouble(5));
                ls.add(g);
            }
        } catch(Exception e){
            System.out.println("Error: "+e.toString());
        } finally{
            try{
                rs.close();
                sttm.close();
                conn.close();
            } catch(Exception e){
                
            }
        }
        return ls;
    }
     
    public Grade getOneGradeByStudentID(String studentID){    
    Connection conn = null;
    PreparedStatement sttm = null;
    ResultSet rs = null;
    try{
        String sSQL = "SELECT dbo.Grade.studentID, dbo.Student.studentName"
                    + "dbo.Grade.Englsh, dbo.Grade.physicalEducation, dbo.Grade.Informatics"
                    + "FROM dbo.Grade INNER JOIN dbo.Student ON dbo.Grade.studentID = dbo.Student.studentID where Grade.studentID = ? ";
        conn = DatabaseUtils.getDBConnect();
        sttm = conn.prepareStatement(sSQL);
        sttm.setString(1, studentID);   
        rs = sttm.executeQuery();
                while(rs.next()){
                Grade g = new Grade();
                g.setSv (new Student(rs.getString(1), rs.getString(2)));
                g.setEnglish(rs.getDouble(3));
                g.setInformatics(rs.getDouble(4));
                g.setPhysicalEducation(rs.getDouble(5));
                return g;
                }
    } catch(Exception e){
        System.out.println("Error: " +e.toString());
    } finally{
        try{
            conn.close();
            rs.close();
            sttm.close();
        } catch(Exception e){
        }
    }
    return null;

}


    
    public Grade getAtPosition(int pos) {
        return ls.get(pos);
    }
}






    
