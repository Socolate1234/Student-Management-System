/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import database.DatabaseUtils;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 *
 * @author Xuan Truong
 * @author Quang Nguyen
 * @author Quoc Thai
 */
public class StudentDAO {
   SimpleDateFormat format_date = new SimpleDateFormat("YYYY/MM/dd");
   public static List<Student> ls = new ArrayList<>();
//    public int add(Student sv){
//        ls.add(sv);
//        return 1;
//    }
    public int add(Student sv){
        Connection conn = null;
        PreparedStatement sttm = null;
        try{
            String sSQL = "INSERT INTO Student (studentID, studentName, dateOfBirth, gender, address, pictures) VALUES (?, ?, ?, ?, ?, ?)";
            conn = (Connection)DatabaseUtils.getDBConnect();
            sttm = conn.prepareStatement(sSQL);
            sttm.setString(1, sv.getStudentID());
            sttm.setString(2, sv.getStudentName());
            sttm.setString(3, format_date.format(sv.getDateOfBirth())); //dateOfBirth
            
            sttm.setBoolean(4, sv.isGender());
            sttm.setString(5, sv.getAddress());
            sttm.setString(6, sv.getPictures());
            if(sttm.executeUpdate() > 0){
                System.out.println("add completed");
                return 1;
            }
        } catch(Exception e){
            System.out.println("Error: "+e.toString());
        } finally{
            try{
                conn.close();
                sttm.close();
            } catch(Exception e){    
            }
        }
        return -1;
    }
    
    
    
//    public List<Student> getAllStudent(){
//        return ls;
//    }
        public List<Student> getAllStudent(){
        List<Student> ls = new ArrayList<>();
        Connection conn = null;
        Statement sttm = null;
        ResultSet rs = null;
        try{
            String sSQL = "Select * from Student";
            conn = DatabaseUtils.getDBConnect();
            sttm = conn.createStatement();
            rs = sttm.executeQuery(sSQL);
            while(rs.next()){
                Student sv = new Student();
                sv.setStudentID(rs.getString(1));
                sv.setStudentName(rs.getString(2));
                sv.setDateOfBirth(rs.getDate(3));
                sv.setGender(rs.getBoolean(4));
                sv.setAddress(rs.getString(5));
                sv.setPictures(rs.getString(6));
                ls.add(sv);
            }
        } catch(Exception e){
            System.out.println("Error: "+e.toString());
        } finally{
            try{
                rs.close();
                sttm.close();
                conn.close();
            } catch(Exception e){
                
            }
        }
        return ls;
    }
    
//public int delStudentbyID(String ma){
//        for (Student sv:ls){
//            if(sv.getStudentID().equalsIgnoreCase(ma)){
//            ls.remove(sv);
//            return 1;
//        }
//    }
//    return  -1;
//}
    
        public int delStudentbyID(String studentID){
        Connection conn = null;
        PreparedStatement sttm = null;
        try{
            String sSQL = "delete Student where studentID = ?";
            conn = (Connection)DatabaseUtils.getDBConnect();
            sttm = conn.prepareStatement(sSQL);
            sttm.setString(1, studentID);
            
            if(sttm.executeUpdate() > 0){
                System.out.println("delete completed");
                return 1;
            }
        } catch(Exception e){
            System.out.println("Error: "+e.toString());
        } finally{
            try{
                conn.close();
                sttm.close();
            } catch(Exception e){    
            }
        }
        return -1;
    }
    
    
   
//public Student getStudentByID(String id){
//      for (Student sv:ls){
//        if (sv.getStudentID().equalsIgnoreCase(id)){
//            return sv;
//            }
//        }
//      return null;
//    }
// 

public Student getStudentByID(String studentID){    
    Connection conn = null;
    PreparedStatement sttm = null;
    ResultSet rs = null;
    Student sv = new Student();
    try{
        String sSQL = "select * from Student where studentID = ?";
        conn = DatabaseUtils.getDBConnect();
        sttm = conn.prepareStatement(sSQL);
        sttm.setString(1, studentID);   
        rs = sttm.executeQuery();
                while(rs.next()){
                    sv.setStudentID(rs.getString(1));
                    sv.setStudentName(rs.getString(2));
                    sv.setDateOfBirth(rs.getDate(3));
                    sv.setGender(rs.getBoolean(4));
                    sv.setAddress(rs.getString(5));
                    sv.setPictures(rs.getString(6));
                    return sv;
                }
    } catch(Exception e){
        System.out.println("Error: " +e.toString());
    } finally{
        try{
            conn.close();
            rs.close();
            sttm.close();
        } catch(Exception e){
        }
    }
    return null;
}
//public int updateStudentByID(Student svNew){
//    for(Student sv: ls){
//        if (sv.getStudentID().equalsIgnoreCase(svNew.getStudentID())){
//            sv.setAddress(svNew.getAddress());
//            sv.setGender(svNew.isGender());
//            sv.setPictures(svNew.getPictures());
//            sv.setDateOfBirth(svNew.getDateOfBirth());
//            sv.setStudentName(svNew.getStudentName());
//            return 1;
//        }
//            
//        }
//    return -1;
//    }

  public int updateStudentByID(Student sv){
        Connection conn = null;
        PreparedStatement sttm = null;
        try{
            String sSQL = "update Student set studentName = ?, dateOfBirth = ?, gender = ?, address = ?, pictures = ? where studentID = ?";
            conn = (Connection)DatabaseUtils.getDBConnect();
            sttm = conn.prepareStatement(sSQL);
            sttm.setString(6, sv.getStudentID());
            sttm.setString(1, sv.getStudentName());
            sttm.setString(2, format_date.format(sv.getDateOfBirth())); //dateOfBirth
            
            sttm.setBoolean(3, sv.isGender());
            sttm.setString(4, sv.getAddress());
            sttm.setString(5, sv.getPictures());
            if(sttm.executeUpdate() > 0){
                System.out.println("update completed");
                return 1;
            }
        } catch(Exception e){
            System.out.println("Error: "+e.toString());
        } finally{
            try{
                conn.close();
                sttm.close();
            } catch(Exception e){    
            }
        }
        return -1;
    }
   
}
    
            



    