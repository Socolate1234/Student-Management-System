
package model;




import java.util.ArrayList;
import java.util.List;




/**
 *
 * @author Quang
 */
public class GradeDAO {
    List<Grade> ls= new ArrayList<>();
    public int add(Grade d){
        ls.add(d);
        return 1;
    }
    public List<Grade> getAllGrade(){
        return ls;
    }
    public Grade getOneGradeByStudentID(String masv){
        for(Grade d: ls){
            if (d.getSv().getStudentID().equalsIgnoreCase(masv)){
                return d;}}
        return null;
    }
    public int updateGrade(Grade dNew){
        for (Grade d: ls){
            if (d.getSv().getStudentID().equalsIgnoreCase(dNew.getSv().getStudentID())){
                d.setEnglish(dNew.getEnglish());
                d.setPhysicalEducation(dNew.getPhysicalEducation());
                d.setInformatics(dNew.getInformatics());
                return 1;
            }
        }
        return -1;
            }
    public int delGrade(String masv){
        Grade d=getOneGradeByStudentID(masv);
        if (d!=null){
            ls.remove(d);
            return 1;
            
        }
        return -1;
    }
}






    
