/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Xuan Truong
 * @author Quang Nguyen
 * @author Quoc Thai
 */
public class StudentDAO {
   public static List<Student> ls = new ArrayList<>();
    public int add(Student sv){
        ls.add(sv);
        return 1;
    }
    public List<Student> getAllStudent(){
        return ls;
    }
public int delStudentbyID(String ma){
        for (Student sv:ls){
            if(sv.getStudentID().equalsIgnoreCase(ma)){
            ls.remove(sv);
            return 1;
        }
    }
    return  -1;
}
   
public Student getStudentByID(String id){
      for (Student sv:ls){
        if (sv.getStudentID().equalsIgnoreCase(id)){
            return sv;
            }
        }
      return null;
    }
public int updateStudentByID(Student svNew){
    for(Student sv: ls){
        if (sv.getStudentID().equalsIgnoreCase(svNew.getStudentID())){
            sv.setAddress(svNew.getAddress());
            sv.setGender(svNew.isGender());
            sv.setPictures(svNew.getPictures());
            sv.setDateOfBirth(svNew.getDateOfBirth());
            sv.setStudentName(svNew.getStudentName());
            return 1;
        }
            
        }
    return -1;
    }

  
}
    
            



    