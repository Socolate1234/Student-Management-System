/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Xuan Truong
 */
public class StudentDAO {
    List<Student> ls = new ArrayList<>();
    public int add(Student sv){
        ls.add(sv);
        return 1;
    }
    public List<Student> getAllStudent(){
        return ls;
    }
    public int delStudentbyID(String ma){
        for (Student sv:ls){
            if(sv.getStudentID().equalsIgnoreCase(ma)){
            ls.remove(sv);
            return 1;
        }
    }
    return  -1;
}
public Student getStudentByID(String id){
      for (Student sv:ls){
        if (sv.getStudentID().equalsIgnoreCase(id)){
            return sv;
            }
        }
      return null;
    }
}
    