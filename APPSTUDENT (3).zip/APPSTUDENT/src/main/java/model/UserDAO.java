/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Xuan Truong
 */

public class UserDAO {
    
    List<User> ls = new ArrayList<>();   
    public UserDAO(){
        this.ls = new ArrayList<>();
            ls.add(new User("Thuy","12345", true));
            ls.add(new User("Thai","12345", true));
            ls.add(new User("Truong","1234235", true));
            ls.add(new User("adminae","1234512", true));
            ls.add(new User("admin12","1234567", true));
} 
public boolean checkLogin(String username, String password){
   for (User u : ls) {
    if (u.getUsername().equals(username) 
            && u.getPassword().equals(password)) {
        return true;
    }
   }
   return false;
 }
}
