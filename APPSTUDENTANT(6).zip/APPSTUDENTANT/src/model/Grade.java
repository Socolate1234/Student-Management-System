/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Quang
 */
public class Grade {
    private int id;
    private Student sv;
    private double English, physicalEducation,Informatics;

    public Grade(int id, Student sv, double English, double physicalEducation, double Informatics) {
        this.id = id;
        this.sv = sv;
        this.English = English;
        this.physicalEducation = physicalEducation;
        this.Informatics = Informatics;
    }

    public Grade() {
       
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Student getSv() {
        return sv;
    }

    public void setSv(Student sv) {
        this.sv = sv;
    }

    public double getEnglish() {
        return English;
    }

    public void setEnglish(double English) {
        this.English = English;
    }

    public double getPhysicalEducation() {
        return physicalEducation;
    }

    public void setPhysicalEducation(double physicalEducation) {
        this.physicalEducation = physicalEducation;
    }

    public double getInformatics() {
        return Informatics;
    }

    public void setInformatics(double Informatics) {
        this.Informatics = Informatics;
    }

   public double getAverage(){
       return (getEnglish()+getPhysicalEducation()+getInformatics())/3 ; 
   }
   public String getClassification(){
       String xl="";
       double tbc= getAverage();
       if(tbc>8){
           xl="GOOD";
       }
       else if (tbc>=7){
           xl="FAIR";
       }
       else if (tbc>=5){
           xl="AVERAGE";
           
       }
       else{
           xl="BAD";
       }
       return xl;
   }
}
